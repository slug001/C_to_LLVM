編譯和執行方式:
輸入make就可以編譯和執行了!


執行後會把test.c test2.c test3.c 這三個C code拆解成一個個token，並等待parser呼叫，如果parser有正確的grammar rule就會一行行印出grammar rule。
