
#include <stdio.h>
#include <string.h>

void main(){
	int   a;  
	float b=1.45628;
	int c= 55688;
	short ss=90;
	char dc[] = "dcsjyd" ;
	char liter = 'p';
	b*=c;
	if (c+3){
		c=c+5*b;
	}else if(c>b){
		c=c*7+(5+b);
	}else if(c++){
		return c;
	}else{
		c = 980;
	}
	a = b+1;
	while(a == 1){
		if(a == 9.4556){
			a=800;
			continue;
		}else if(a == b){
			a=a-9*777;
			break;
		}
	}

	for(int i=0;i<100;i++){
    	i=i+1;
	}
	int g;
	int h;
	scanf("%d%d",&g,&h);
	printf("%d",g);
	printf(" %d  %d ",g,h);
    char poll[]="polly";

	return 0;
	return "sagjufkg";
	return 'p';
}
