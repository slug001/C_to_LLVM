void main()
{
		int a;
		float b;

		a = b+1;
		b = a + 2 - 3 * 4 + 5;
}
