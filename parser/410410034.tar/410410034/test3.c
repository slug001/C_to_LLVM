void main()
{
		int a;
		float b;

		a = b+1;
		if (a) { a = (2+4)-3; }
}
